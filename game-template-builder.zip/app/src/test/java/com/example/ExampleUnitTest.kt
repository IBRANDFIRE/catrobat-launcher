package com.example

import com.example.catrobat.parser.CatrobatParser
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.io.FileInputStream

class ExampleUnitTest {
  @Test
  fun testParseCodeXml() {
    val file = File("src/main/assets/project/code.xml")
    assertTrue("File should exist at " + file.absolutePath, file.exists())
    try {
      FileInputStream(file).use { stream ->
        val program = CatrobatParser.parse(stream)
        assertNotNull(program)
        println("Program parsed successfully: ${program.header.programName}, scenes: ${program.scenes.size}")
      }
    } catch (e: org.xml.sax.SAXParseException) {
      System.err.println("SAXParseException at line ${e.lineNumber}, col ${e.columnNumber}: ${e.message}")
      e.printStackTrace()
      throw e
    } catch (e: Exception) {
      System.err.println("Exception: ${e.message}")
      e.printStackTrace()
      throw e
    }
  }
}

