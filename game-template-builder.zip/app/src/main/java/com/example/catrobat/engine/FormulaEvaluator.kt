package com.example.catrobat.engine

import com.example.catrobat.model.FormulaNode
import java.util.regex.Pattern
import kotlin.math.*
import kotlin.random.Random

interface EngineContext {
    fun getVariable(name: String): Any
    fun getList(name: String): List<Any>
    fun getCustomInput(name: String): Any?
    fun getSpriteSensor(sensorName: String): Any
    fun checkCollision(spriteName: String): Boolean
    fun checkColorTouchesColor(color1: String, color2: String): Boolean
    fun checkCollidesWithColor(color: String): Boolean
}

object FormulaEvaluator {

    fun evaluate(node: FormulaNode?, context: EngineContext): Any {
        if (node == null) return 0.0

        return when (node.type.uppercase()) {
            "NUMBER" -> node.value.toDoubleOrNull() ?: 0.0
            "STRING" -> node.value
            "USER_VARIABLE" -> context.getVariable(node.value)
            "USER_LIST" -> context.getList(node.value)
            "USER_DEFINED_BRICK_INPUT" -> context.getCustomInput(node.value) ?: node.value
            "SENSOR" -> context.getSpriteSensor(node.value)
            "COLLISION_FORMULA" -> if (context.checkCollision(node.value)) 1.0 else 0.0

            "OPERATOR" -> evaluateOperator(node, context)
            "FUNCTION" -> evaluateFunction(node, context)
            else -> node.value
        }
    }

    private fun evaluateOperator(node: FormulaNode, context: EngineContext): Any {
        val op = node.value.uppercase()
        val leftVal = node.leftChild?.let { evaluate(it, context) }
        val rightVal = node.rightChild?.let { evaluate(it, context) }

        return when (op) {
            "PLUS" -> {
                if (leftVal is String || rightVal is String) {
                    toDisplayString(leftVal ?: "") + toDisplayString(rightVal ?: "")
                } else {
                    toDouble(leftVal) + toDouble(rightVal)
                }
            }
            "MINUS" -> {
                if (leftVal == null) -toDouble(rightVal)
                else toDouble(leftVal) - toDouble(rightVal)
            }
            "MULT" -> toDouble(leftVal) * toDouble(rightVal)
            "DIVIDE" -> {
                val r = toDouble(rightVal)
                if (r == 0.0) 0.0 else toDouble(leftVal) / r
            }
            "EQUAL" -> {
                if (leftVal is Number && rightVal is Number) {
                    if (leftVal.toDouble() == rightVal.toDouble()) 1.0 else 0.0
                } else {
                    val s1 = toDisplayString(leftVal)
                    val s2 = toDisplayString(rightVal)
                    val d1 = s1.toDoubleOrNull()
                    val d2 = s2.toDoubleOrNull()
                    if (d1 != null && d2 != null) {
                        if (d1 == d2) 1.0 else 0.0
                    } else {
                        if (s1.equals(s2, ignoreCase = true)) 1.0 else 0.0
                    }
                }
            }
            "NOT_EQUAL" -> {
                val eq = evaluateOperator(node.copy(value = "EQUAL"), context)
                if (toBool(eq)) 0.0 else 1.0
            }
            "SMALLER_THAN" -> if (toDouble(leftVal) < toDouble(rightVal)) 1.0 else 0.0
            "SMALLER_OR_EQUAL" -> if (toDouble(leftVal) <= toDouble(rightVal)) 1.0 else 0.0
            "GREATER_THAN" -> if (toDouble(leftVal) > toDouble(rightVal)) 1.0 else 0.0
            "GREATER_OR_EQUAL" -> if (toDouble(leftVal) >= toDouble(rightVal)) 1.0 else 0.0
            "LOGICAL_AND" -> if (toBool(leftVal) && toBool(rightVal)) 1.0 else 0.0
            "LOGICAL_OR" -> if (toBool(leftVal) || toBool(rightVal)) 1.0 else 0.0
            "LOGICAL_NOT" -> if (!toBool(rightVal ?: leftVal)) 1.0 else 0.0
            else -> 0.0
        }
    }

    private fun evaluateFunction(node: FormulaNode, context: EngineContext): Any {
        val func = node.value.uppercase()
        val leftVal = node.leftChild?.let { evaluate(it, context) }
        val rightVal = node.rightChild?.let { evaluate(it, context) }

        return when (func) {
            "TRUE" -> 1.0
            "FALSE" -> 0.0
            "PI" -> Math.PI

            // Trig (degrees in Pocket Code)
            "SIN" -> sin(Math.toRadians(toDouble(leftVal)))
            "COS" -> cos(Math.toRadians(toDouble(leftVal)))
            "TAN" -> tan(Math.toRadians(toDouble(leftVal)))
            "ARCSIN" -> Math.toDegrees(asin(toDouble(leftVal).coerceIn(-1.0, 1.0)))
            "ARCCOS" -> Math.toDegrees(acos(toDouble(leftVal).coerceIn(-1.0, 1.0)))
            "ARCTAN" -> Math.toDegrees(atan(toDouble(leftVal)))
            "ARCTAN2" -> Math.toDegrees(atan2(toDouble(leftVal), toDouble(rightVal)))

            "LN" -> {
                val v = toDouble(leftVal)
                if (v <= 0) 0.0 else ln(v)
            }
            "LOG" -> {
                val v = toDouble(leftVal)
                if (v <= 0) 0.0 else log10(v)
            }
            "EXP" -> exp(toDouble(leftVal))
            "POWER" -> toDouble(leftVal).pow(toDouble(rightVal))
            "SQRT" -> {
                val v = toDouble(leftVal)
                if (v < 0) 0.0 else sqrt(v)
            }
            "ABS" -> abs(toDouble(leftVal))
            "ROUND" -> round(toDouble(leftVal))
            "FLOOR" -> floor(toDouble(leftVal))
            "CEIL" -> ceil(toDouble(leftVal))
            "MOD" -> {
                val r = toDouble(rightVal)
                if (r == 0.0) 0.0 else toDouble(leftVal) % r
            }
            "RAND" -> {
                val min = toDouble(leftVal)
                val max = toDouble(rightVal)
                if (min >= max) min else min + Random.nextDouble() * (max - min)
            }
            "MIN" -> min(toDouble(leftVal), toDouble(rightVal))
            "MAX" -> max(toDouble(leftVal), toDouble(rightVal))

            // Conditional
            "IF_THEN_ELSE" -> {
                val cond = toBool(leftVal)
                if (cond) {
                    rightVal ?: 0.0
                } else {
                    if (node.additionalChildren.isNotEmpty()) {
                        evaluate(node.additionalChildren[0], context)
                    } else 0.0
                }
            }

            // String functions
            "LENGTH" -> {
                when (leftVal) {
                    is List<*> -> leftVal.size.toDouble()
                    else -> toDisplayString(leftVal).length.toDouble()
                }
            }
            "LETTER" -> {
                val idx = toDouble(leftVal).toInt() - 1 // 1-indexed
                val str = toDisplayString(rightVal)
                if (idx in str.indices) str[idx].toString() else ""
            }
            "SUBTEXT" -> {
                // start: leftVal, end: rightVal, string: additionalChildren[0]
                val startIdx = (toDouble(leftVal).toInt() - 1).coerceAtLeast(0)
                val endIdx = toDouble(rightVal).toInt()
                val targetStr = if (node.additionalChildren.isNotEmpty()) {
                    toDisplayString(evaluate(node.additionalChildren[0], context))
                } else ""
                val actualEnd = endIdx.coerceIn(startIdx, targetStr.length)
                if (startIdx in targetStr.indices) targetStr.substring(startIdx, actualEnd) else ""
            }
            "JOIN" -> toDisplayString(leftVal) + toDisplayString(rightVal)
            "JOIN3" -> {
                val s1 = toDisplayString(leftVal)
                val s2 = toDisplayString(rightVal)
                val s3 = if (node.additionalChildren.isNotEmpty()) {
                    toDisplayString(evaluate(node.additionalChildren[0], context))
                } else ""
                s1 + s2 + s3
            }
            "REGEX" -> {
                val patternStr = toDisplayString(leftVal)
                val targetStr = toDisplayString(rightVal)
                try {
                    val p = Pattern.compile(patternStr)
                    val m = p.matcher(targetStr)
                    if (m.find()) {
                        if (m.groupCount() >= 1) m.group(1) ?: m.group(0) else m.group(0)
                    } else ""
                } catch (e: Exception) {
                    ""
                }
            }

            // List functions
            "FLATTEN" -> {
                val list = when (leftVal) {
                    is List<*> -> leftVal
                    else -> emptyList<Any>()
                }
                list.joinToString(" ") { toDisplayString(it) }
            }
            "NUMBER_OF_ITEMS" -> {
                val list = when (leftVal) {
                    is List<*> -> leftVal
                    else -> emptyList<Any>()
                }
                list.size.toDouble()
            }
            "LIST_ITEM" -> {
                val idx = toDouble(leftVal).toInt() - 1 // 1-indexed
                val list = when (rightVal) {
                    is List<*> -> rightVal
                    else -> emptyList<Any>()
                }
                if (idx in list.indices) list[idx] ?: 0.0 else 0.0
            }
            "CONTAINS" -> {
                // left is list, right is item
                val list = when (leftVal) {
                    is List<*> -> leftVal
                    else -> emptyList<Any>()
                }
                val target = toDisplayString(rightVal)
                val found = list.any { toDisplayString(it) == target }
                if (found) 1.0 else 0.0
            }
            "INDEX_OF_ITEM" -> {
                val target = toDisplayString(leftVal)
                val list = when (rightVal) {
                    is List<*> -> rightVal
                    else -> emptyList<Any>()
                }
                val idx = list.indexOfFirst { toDisplayString(it) == target }
                if (idx >= 0) (idx + 1).toDouble() else 0.0
            }

            // Color sensors
            "COLOR_TOUCHES_COLOR" -> {
                val c1 = toDisplayString(leftVal)
                val c2 = toDisplayString(rightVal)
                if (context.checkColorTouchesColor(c1, c2)) 1.0 else 0.0
            }
            "COLLIDES_WITH_COLOR" -> {
                val c = toDisplayString(leftVal)
                if (context.checkCollidesWithColor(c)) 1.0 else 0.0
            }

            else -> 0.0
        }
    }

    fun toDouble(v: Any?): Double {
        return when (v) {
            null -> 0.0
            is Number -> v.toDouble()
            is Boolean -> if (v) 1.0 else 0.0
            is String -> v.toDoubleOrNull() ?: 0.0
            else -> 0.0
        }
    }

    fun toBool(v: Any?): Boolean {
        return when (v) {
            null -> false
            is Boolean -> v
            is Number -> v.toDouble() != 0.0
            is String -> v.isNotEmpty() && v != "0" && !v.equals("false", ignoreCase = true)
            else -> false
        }
    }

    fun toDisplayString(v: Any?): String {
        return when (v) {
            null -> ""
            is Double -> {
                if (v == v.toLong().toDouble()) v.toLong().toString() else v.toString()
            }
            is Float -> {
                if (v == v.toLong().toFloat()) v.toLong().toString() else v.toString()
            }
            is Number -> v.toString()
            is Boolean -> if (v) "1" else "0"
            is String -> v
            is List<*> -> v.joinToString(", ") { toDisplayString(it) }
            else -> v.toString()
        }
    }
}
