package com.example.catrobat.engine

import android.content.Context
import android.net.Uri
import com.example.catrobat.model.CatrobatProgram
import com.example.catrobat.parser.CatrobatParser
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

object ProjectZipLoader {

    fun loadFromUri(context: Context, uri: Uri): Pair<CatrobatProgram, String>? {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return null
            val destDir = File(context.filesDir, "custom_project")
            destDir.deleteRecursively()
            destDir.mkdirs()

            val zis = ZipInputStream(inputStream)
            var entry = zis.nextEntry
            var codeXmlFile: File? = null

            while (entry != null) {
                val f = File(destDir, entry.name)
                if (entry.isDirectory) {
                    f.mkdirs()
                } else {
                    f.parentFile?.mkdirs()
                    val fos = FileOutputStream(f)
                    zis.copyTo(fos)
                    fos.close()
                    if (f.name == "code.xml") {
                        codeXmlFile = f
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
            zis.close()

            if (codeXmlFile == null || !codeXmlFile.exists()) {
                // Search recursively for code.xml
                codeXmlFile = destDir.walkTopDown().firstOrNull { it.name == "code.xml" }
            }

            if (codeXmlFile != null && codeXmlFile.exists()) {
                val program = CatrobatParser.parse(codeXmlFile.inputStream())
                Pair(program, destDir.name)
            } else {
                null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
