package com.example.catrobat.ui

import android.graphics.Bitmap
import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import com.example.catrobat.engine.CatrobatEngine
import com.example.catrobat.engine.PenStamp
import com.example.catrobat.engine.PenStroke
import com.example.catrobat.engine.SpriteRuntime
import kotlin.math.min

@Composable
fun GameView(
    engine: CatrobatEngine,
    modifier: Modifier = Modifier
) {
    val sprites by engine.sprites.collectAsState()
    val penStrokes by engine.penStrokes.collectAsState()
    val penStamps by engine.penStamps.collectAsState()

    val screenW = engine.program.header.screenWidth.toFloat()
    val screenH = engine.program.header.screenHeight.toFloat()

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        val cw = constraints.maxWidth.toFloat()
        val ch = constraints.maxHeight.toFloat()

        val scale = min(cw / screenW, ch / screenH)
        val viewportW = screenW * scale
        val viewportH = screenH * scale
        val offsetX = (cw - viewportW) / 2f
        val offsetY = (ch - viewportH) / 2f

        fun toGameX(canvasX: Float): Double =
            ((canvasX - offsetX - (viewportW / 2f)) / scale).toDouble()

        fun toGameY(canvasY: Float): Double =
            (-((canvasY - offsetY - (viewportH / 2f)) / scale)).toDouble()

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(scale, offsetX, offsetY) {
                    detectTapGestures(
                        onPress = { offset ->
                            val gx = toGameX(offset.x)
                            val gy = toGameY(offset.y)
                            engine.onTouchDown(gx, gy)
                            tryAwaitRelease()
                            engine.onTouchUp()
                        }
                    )
                }
                .pointerInput(scale, offsetX, offsetY) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            val gx = toGameX(offset.x)
                            val gy = toGameY(offset.y)
                            engine.onTouchDown(gx, gy)
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            val gx = toGameX(change.position.x)
                            val gy = toGameY(change.position.y)
                            engine.onTouchMove(gx, gy)
                        },
                        onDragEnd = {
                            engine.onTouchUp()
                        },
                        onDragCancel = {
                            engine.onTouchUp()
                        }
                    )
                }
        ) {
            // Draw background viewport bounds
            drawRect(
                color = Color(0xFF1E1E2C),
                topLeft = Offset(offsetX, offsetY),
                size = Size(viewportW, viewportH)
            )

            // Draw Pen Stamps
            for (stamp in penStamps) {
                drawPenStamp(stamp, offsetX, offsetY, viewportW, viewportH, scale)
            }

            // Draw Pen Strokes
            for (stroke in penStrokes) {
                drawPenStroke(stroke, offsetX, offsetY, viewportW, viewportH, scale)
            }

            // Draw Sprites sorted by layer
            val sorted = sprites.filter { it.visible }.sortedBy { it.layer }
            for (sr in sorted) {
                drawSprite(sr, offsetX, offsetY, viewportW, viewportH, scale)
            }
        }
    }
}

private fun DrawScope.drawPenStamp(
    stamp: PenStamp,
    offsetX: Float,
    offsetY: Float,
    viewportW: Float,
    viewportH: Float,
    scale: Float
) {
    val px = offsetX + (viewportW / 2f) + (stamp.x * scale)
    val py = offsetY + (viewportH / 2f) - (stamp.y * scale)
    val bmpW = stamp.bitmap.width * stamp.scale * scale
    val bmpH = stamp.bitmap.height * stamp.scale * scale

    drawIntoCanvas { canvas ->
        canvas.save()
        canvas.translate(px, py)
        canvas.rotate(stamp.rotation - 90f)
        val imageBitmap = stamp.bitmap.asImageBitmap()
        drawImage(
            image = imageBitmap,
            topLeft = Offset(-bmpW / 2f, -bmpH / 2f),
            alpha = stamp.alpha
        )
        canvas.restore()
    }
}

private fun DrawScope.drawPenStroke(
    stroke: PenStroke,
    offsetX: Float,
    offsetY: Float,
    viewportW: Float,
    viewportH: Float,
    scale: Float
) {
    val sx = offsetX + (viewportW / 2f) + (stroke.x1 * scale)
    val sy = offsetY + (viewportH / 2f) - (stroke.y1 * scale)
    val ex = offsetX + (viewportW / 2f) + (stroke.x2 * scale)
    val ey = offsetY + (viewportH / 2f) - (stroke.y2 * scale)

    drawLine(
        color = Color(stroke.color),
        start = Offset(sx, sy),
        end = Offset(ex, ey),
        strokeWidth = (stroke.width * scale).coerceAtLeast(1f)
    )
}

private fun DrawScope.drawSprite(
    sr: SpriteRuntime,
    offsetX: Float,
    offsetY: Float,
    viewportW: Float,
    viewportH: Float,
    scale: Float
) {
    val bmp = sr.getCurrentBitmap()
    val px = offsetX + (viewportW / 2f) + (sr.x.toFloat() * scale)
    val py = offsetY + (viewportH / 2f) - (sr.y.toFloat() * scale)
    val alpha = ((100.0 - sr.transparency) / 100.0).toFloat().coerceIn(0f, 1f)

    if (bmp != null) {
        val sizeFactor = (sr.size / 100.0).toFloat()
        val drawW = bmp.width * sizeFactor * scale
        val drawH = bmp.height * sizeFactor * scale

        // Rotation
        val rotAngle = when (sr.rotationStyle) {
            0 -> 0f // LEFT_RIGHT handled via scaleX
            2 -> 0f // DONT_ROTATE
            else -> (sr.direction.toFloat() - 90f)
        }

        val flipX = if (sr.rotationStyle == 0 && (sr.direction % 360 < 0 || sr.direction % 360 > 180)) -1f else 1f

        drawIntoCanvas { canvas ->
            canvas.save()
            canvas.translate(px, py)
            canvas.rotate(rotAngle)
            canvas.scale(flipX, 1f)

            val imageBmp = bmp.asImageBitmap()
            drawImage(
                image = imageBmp,
                dstOffset = androidx.compose.ui.unit.IntOffset((-drawW / 2f).toInt(), (-drawH / 2f).toInt()),
                dstSize = androidx.compose.ui.unit.IntSize(drawW.toInt(), drawH.toInt()),
                alpha = alpha
            )
            canvas.restore()
        }
    }

    // Text overlay if any
    sr.activeTextOverlay?.let { textOverlay ->
        drawIntoCanvas { canvas ->
            val textPaint = Paint().apply {
                color = try {
                    android.graphics.Color.parseColor(textOverlay.colorHex)
                } catch (_: Exception) {
                    android.graphics.Color.RED
                }
                textSize = (textOverlay.size * scale).coerceAtLeast(16f)
                isAntiAlias = true
                textAlign = when (textOverlay.alignment) {
                    0 -> Paint.Align.LEFT
                    2 -> Paint.Align.RIGHT
                    else -> Paint.Align.CENTER
                }
            }
            val tx = px + (textOverlay.x * scale)
            val ty = py - (textOverlay.y * scale)
            canvas.nativeCanvas.drawText(textOverlay.text, tx, ty, textPaint)
        }
    }
}
