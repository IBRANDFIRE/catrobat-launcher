package com.example.catrobat.parser

import com.example.catrobat.model.*
import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.InputStream
import javax.xml.parsers.DocumentBuilderFactory

object CatrobatParser {

    fun parse(inputStream: InputStream): CatrobatProgram {
        val factory = DocumentBuilderFactory.newInstance()
        factory.isNamespaceAware = false
        val builder = factory.newDocumentBuilder()
        val doc = builder.parse(inputStream)
        doc.documentElement.normalize()

        val root = doc.documentElement
        val header = parseHeader(root)
        val program = CatrobatProgram(header = header)

        // Parse global variables
        parseGlobalVariables(root, program)

        // Parse scenes
        val scenesNode = findChild(root, "scenes")
        if (scenesNode != null) {
            val sceneElements = findChildren(scenesNode, "scene")
            for (sceneEl in sceneElements) {
                val scene = parseScene(sceneEl, root)
                program.scenes.add(scene)
            }
        }

        return program
    }

    private fun parseHeader(root: Element): ProgramHeader {
        val headerEl = findChild(root, "header") ?: return ProgramHeader()
        val appName = getChildText(headerEl, "applicationName") ?: "Pocket Code"
        val progName = getChildText(headerEl, "programName") ?: "Pocket Code Project"
        val landscape = getChildText(headerEl, "landscapeMode")?.toBooleanStrictOrNull() ?: true
        val width = getChildText(headerEl, "screenWidth")?.toIntOrNull() ?: 1280
        val height = getChildText(headerEl, "screenHeight")?.toIntOrNull() ?: 720
        val mode = getChildText(headerEl, "screenMode") ?: "STRETCH"
        val desc = getChildText(headerEl, "description") ?: ""
        val version = getChildText(headerEl, "catrobatLanguageVersion") ?: "1.14"

        return ProgramHeader(
            applicationName = appName,
            programName = progName,
            landscapeMode = landscape,
            screenWidth = width,
            screenHeight = height,
            screenMode = mode,
            description = desc,
            catrobatLanguageVersion = version
        )
    }

    private fun parseGlobalVariables(root: Element, program: CatrobatProgram) {
        val varListEl = findChild(root, "programVariableList")
        if (varListEl != null) {
            val userVars = findChildren(varListEl, "userVariable")
            for (uv in userVars) {
                val name = resolveVariableName(uv)
                if (!name.isNullOrBlank()) {
                    program.globalVariables.putIfAbsent(name, 0.0)
                }
            }
        }

        val listListEl = findChild(root, "programListOfLists")
        if (listListEl != null) {
            val userLists = findChildren(listListEl, "userList")
            for (ul in userLists) {
                val name = resolveVariableName(ul)
                if (!name.isNullOrBlank()) {
                    program.globalLists.putIfAbsent(name, mutableListOf())
                }
            }
        }
    }

    private fun parseScene(sceneEl: Element, root: Element): Scene {
        val sceneName = getChildText(sceneEl, "name") ?: "Scene"
        val scene = Scene(name = sceneName)

        val objListEl = findChild(sceneEl, "objectList")
        if (objListEl != null) {
            val objectNodes = findChildren(objListEl, "object")
            for (objNode in objectNodes) {
                val resolvedObj = if (objNode.hasAttribute("reference")) {
                    resolveElement(objNode, objNode.getAttribute("reference")) ?: objNode
                } else {
                    objNode
                }
                val sprite = parseSprite(resolvedObj)
                scene.sprites.add(sprite)
            }
        }
        return scene
    }

    private fun parseSprite(objEl: Element): SpriteObject {
        val name = objEl.getAttribute("name").ifEmpty {
            getChildText(objEl, "name") ?: "Sprite"
        }
        val type = objEl.getAttribute("type").ifEmpty { "Sprite" }
        val sprite = SpriteObject(name = name, type = type)

        // Looks
        val lookListEl = findChild(objEl, "lookList")
        if (lookListEl != null) {
            val looks = findChildren(lookListEl, "look")
            for (l in looks) {
                val resolvedLook = if (l.hasAttribute("reference")) {
                    resolveElement(l, l.getAttribute("reference")) ?: l
                } else l
                val fileName = resolvedLook.getAttribute("fileName").ifEmpty {
                    getChildText(resolvedLook, "fileName") ?: ""
                }
                val lookName = resolvedLook.getAttribute("name").ifEmpty {
                    getChildText(resolvedLook, "name") ?: fileName
                }
                if (fileName.isNotEmpty()) {
                    sprite.looks.add(Look(fileName = fileName, name = lookName))
                }
            }
        }

        // Sounds
        val soundListEl = findChild(objEl, "soundList")
        if (soundListEl != null) {
            val sounds = findChildren(soundListEl, "sound")
            for (s in sounds) {
                val resolvedSound = if (s.hasAttribute("reference")) {
                    resolveElement(s, s.getAttribute("reference")) ?: s
                } else s
                val fileName = resolvedSound.getAttribute("fileName").ifEmpty {
                    getChildText(resolvedSound, "fileName") ?: ""
                }
                val soundName = resolvedSound.getAttribute("name").ifEmpty {
                    getChildText(resolvedSound, "name") ?: fileName
                }
                if (fileName.isNotEmpty()) {
                    sprite.sounds.add(Sound(fileName = fileName, name = soundName))
                }
            }
        }

        // Scripts
        val scriptListEl = findChild(objEl, "scriptList")
        if (scriptListEl != null) {
            val scripts = findChildren(scriptListEl, "script")
            for (sc in scripts) {
                val script = parseScript(sc)
                sprite.scripts.add(script)
            }
        }

        return sprite
    }

    private fun parseScript(scEl: Element): Script {
        val type = scEl.getAttribute("type").ifEmpty { "StartScript" }
        val scriptId = getChildText(scEl, "scriptId") ?: ""
        val commented = getChildText(scEl, "commentedOut")?.toBooleanStrictOrNull() ?: false

        val props = mutableMapOf<String, String>()
        getChildText(scEl, "receivedMessage")?.let { props["receivedMessage"] = it }
        getChildText(scEl, "spriteToBounceOffName")?.let { props["spriteToBounceOffName"] = it }
        getChildText(scEl, "userDefinedBrickID")?.let { props["userDefinedBrickID"] = it }

        var conditionFormula: FormulaNode? = null
        val formulaMapEl = findChild(scEl, "formulaMap")
        if (formulaMapEl != null) {
            val f = findChild(formulaMapEl, "formula")
            if (f != null) {
                conditionFormula = parseFormula(f)
            }
        }

        val userDefinedInputs = mutableListOf<String>()
        val inputsEl = findChild(scEl, "userDefinedBrickInputs")
        if (inputsEl != null) {
            val uvList = findChildren(inputsEl, "userVariable")
            for (uv in uvList) {
                resolveVariableName(uv)?.let { userDefinedInputs.add(it) }
            }
        }

        val bricks = mutableListOf<Brick>()
        val brickListEl = findChild(scEl, "brickList")
        if (brickListEl != null) {
            val bEls = findChildren(brickListEl, "brick")
            for (b in bEls) {
                bricks.add(parseBrick(b))
            }
        }

        return Script(
            type = type,
            scriptId = scriptId,
            commentedOut = commented,
            bricks = bricks,
            properties = props,
            conditionFormula = conditionFormula,
            userDefinedBrickID = props["userDefinedBrickID"] ?: "",
            userDefinedInputs = userDefinedInputs
        )
    }

    private fun parseBrick(bEl: Element): Brick {
        val type = bEl.getAttribute("type").ifEmpty { "Brick" }
        val brickId = getChildText(bEl, "brickId") ?: ""
        val commented = getChildText(bEl, "commentedOut")?.toBooleanStrictOrNull() ?: false

        val formulas = mutableMapOf<String, FormulaNode>()
        val fListEl = findChild(bEl, "formulaList")
        if (fListEl != null) {
            val fEls = findChildren(fListEl, "formula")
            for (f in fEls) {
                val cat = f.getAttribute("category").ifEmpty {
                    f.getAttribute("input").ifEmpty { "VALUE" }
                }
                formulas[cat] = parseFormula(f)
            }
        }

        val props = mutableMapOf<String, String>()
        for (propName in listOf(
            "broadcastMessage", "sceneToStart", "sceneForTransition",
            "direction", "selection", "spinnerSelection", "spinnerSelectionID",
            "alignmentSelection", "userDefinedBrickID", "type"
        )) {
            getChildText(bEl, propName)?.let { props[propName] = it }
        }

        // Check look reference
        val lookRef = findChild(bEl, "look")
        if (lookRef != null) {
            val resolved = if (lookRef.hasAttribute("reference")) {
                resolveElement(lookRef, lookRef.getAttribute("reference")) ?: lookRef
            } else lookRef
            val name = resolved.getAttribute("name").ifEmpty {
                getChildText(resolved, "name") ?: resolved.getAttribute("fileName")
            }
            props["lookName"] = name
        }

        // Check sound reference
        val soundRef = findChild(bEl, "sound")
        if (soundRef != null) {
            val resolved = if (soundRef.hasAttribute("reference")) {
                resolveElement(soundRef, soundRef.getAttribute("reference")) ?: soundRef
            } else soundRef
            val name = resolved.getAttribute("name").ifEmpty {
                getChildText(resolved, "name") ?: resolved.getAttribute("fileName")
            }
            val fileName = resolved.getAttribute("fileName").ifEmpty {
                getChildText(resolved, "fileName") ?: name
            }
            props["soundName"] = name
            props["soundFileName"] = fileName
        }

        // Check destinationSprite
        val destSprite = findChild(bEl, "destinationSprite")
            ?: findChild(bEl, "pointedObject")
        if (destSprite != null) {
            val resolved = if (destSprite.hasAttribute("reference")) {
                resolveElement(destSprite, destSprite.getAttribute("reference")) ?: destSprite
            } else destSprite
            val name = resolved.getAttribute("name").ifEmpty {
                getChildText(resolved, "name") ?: ""
            }
            props["destinationSpriteName"] = name
        }

        // Check userVariable
        val userVar = findChild(bEl, "userVariable")
        if (userVar != null) {
            resolveVariableName(userVar)?.let { props["userVariableName"] = it }
        }

        // Check userList
        val userList = findChild(bEl, "userList")
        if (userList != null) {
            resolveVariableName(userList)?.let { props["userListName"] = it }
        }

        // Check userDataList (for ForItemInUserListBrick)
        val userDataList = findChild(bEl, "userDataList")
        if (userDataList != null) {
            val items = findChildren(userDataList, "userData")
            for (ud in items) {
                val cat = ud.getAttribute("category")
                val name = resolveVariableName(ud)
                if (name != null) {
                    props[cat] = name
                }
            }
        }

        // Child loops / branches
        val loopBricks = mutableListOf<Brick>()
        val loopEl = findChild(bEl, "loopBricks")
        if (loopEl != null) {
            val bList = findChildren(loopEl, "brick")
            for (b in bList) loopBricks.add(parseBrick(b))
        }

        val ifBranchBricks = mutableListOf<Brick>()
        val ifEl = findChild(bEl, "ifBranchBricks")
        if (ifEl != null) {
            val bList = findChildren(ifEl, "brick")
            for (b in bList) ifBranchBricks.add(parseBrick(b))
        }

        val elseBranchBricks = mutableListOf<Brick>()
        val elseEl = findChild(bEl, "elseBranchBricks")
        if (elseEl != null) {
            val bList = findChildren(elseEl, "brick")
            for (b in bList) elseBranchBricks.add(parseBrick(b))
        }

        // User defined brick data
        val uDefInputs = mutableListOf<String>()
        val uDataList = findChild(bEl, "userDefinedBrickDataList")
        if (uDataList != null) {
            val inputs = findChildren(uDataList, "userDefinedBrickInput")
            for (inp in inputs) {
                val innerInput = findChild(inp, "input")
                val text = innerInput?.let { getChildText(it, "input") } ?: getChildText(inp, "input") ?: ""
                uDefInputs.add(text)
            }
        }

        return Brick(
            type = type,
            brickId = brickId,
            commentedOut = commented,
            formulas = formulas,
            loopBricks = loopBricks,
            ifBranchBricks = ifBranchBricks,
            elseBranchBricks = elseBranchBricks,
            properties = props,
            userDefinedBrickID = props["userDefinedBrickID"] ?: "",
            userDefinedInputs = uDefInputs
        )
    }

    private fun parseFormula(fEl: Element): FormulaNode {
        val type = getChildText(fEl, "type") ?: "NUMBER"
        val value = getChildText(fEl, "value") ?: ""

        val leftEl = findChild(fEl, "leftChild")
        val leftNode = leftEl?.let { parseFormula(it) }

        val rightEl = findChild(fEl, "rightChild")
        val rightNode = rightEl?.let { parseFormula(it) }

        val addList = mutableListOf<FormulaNode>()
        val addEl = findChild(fEl, "additionalChildren")
        if (addEl != null) {
            val children = addEl.childNodes
            for (i in 0 until children.length) {
                val c = children.item(i)
                if (c is Element) {
                    addList.add(parseFormula(c))
                }
            }
        }

        return FormulaNode(
            type = type,
            value = value,
            leftChild = leftNode,
            rightChild = rightNode,
            additionalChildren = addList
        )
    }

    fun resolveVariableName(el: Element): String? {
        val target = if (el.hasAttribute("reference")) {
            resolveElement(el, el.getAttribute("reference")) ?: el
        } else {
            el
        }

        // Check if target has <name> directly
        getChildText(target, "name")?.let { return it }

        // Check target's <default><name>
        val def = findChild(target, "default")
        if (def != null) {
            getChildText(def, "name")?.let { return it }
        }

        // Check child <userVariable>
        val uv = findChild(target, "userVariable")
        if (uv != null) {
            return resolveVariableName(uv)
        }

        // Check attribute name
        if (target.hasAttribute("name")) {
            return target.getAttribute("name")
        }

        return null
    }

    private fun resolveElement(context: Element, refPath: String): Element? {
        var curr: Node? = context
        val segments = refPath.split("/")
        for (seg in segments) {
            if (curr == null) return null
            if (seg.isEmpty() || seg == ".") continue
            if (seg == "..") {
                curr = curr.parentNode
                continue
            }
            val bracketOpen = seg.indexOf('[')
            val tagName: String
            val index: Int
            if (bracketOpen != -1) {
                tagName = seg.substring(0, bracketOpen)
                val bracketClose = seg.indexOf(']', bracketOpen)
                val idxStr = seg.substring(bracketOpen + 1, bracketClose)
                index = idxStr.toIntOrNull() ?: 1
            } else {
                tagName = seg
                index = 1
            }

            var count = 0
            var foundChild: Element? = null
            val children = curr.childNodes
            for (i in 0 until children.length) {
                val child = children.item(i)
                if (child is Element && child.nodeName == tagName) {
                    count++
                    if (count == index) {
                        foundChild = child
                        break
                    }
                }
            }
            curr = foundChild
        }
        return curr as? Element
    }

    private fun findChild(parent: Element, tagName: String): Element? {
        val children = parent.childNodes
        for (i in 0 until children.length) {
            val c = children.item(i)
            if (c is Element && c.nodeName == tagName) {
                return c
            }
        }
        return null
    }

    private fun findChildren(parent: Element, tagName: String): List<Element> {
        val list = mutableListOf<Element>()
        val children = parent.childNodes
        for (i in 0 until children.length) {
            val c = children.item(i)
            if (c is Element && c.nodeName == tagName) {
                list.add(c)
            }
        }
        return list
    }

    private fun getChildText(parent: Element, tagName: String): String? {
        val child = findChild(parent, tagName) ?: return null
        return child.textContent?.trim()
    }
}
