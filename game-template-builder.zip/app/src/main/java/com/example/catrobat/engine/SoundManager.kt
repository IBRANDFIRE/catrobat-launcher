package com.example.catrobat.engine

import android.content.Context
import android.content.res.AssetFileDescriptor
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.util.Log
import java.io.File

class SoundManager(private val context: Context) {
    private val activePlayers = mutableListOf<MediaPlayer>()
    private var globalVolume: Float = 1.0f

    fun playSound(
        fileName: String,
        sceneName: String,
        projectDir: String = "project",
        wait: Boolean = false,
        onComplete: (() -> Unit)? = null
    ) {
        try {
            val player = MediaPlayer()
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .build()
            )

            val opened = openAssetOrFile(fileName, sceneName, projectDir, player)
            if (!opened) {
                Log.w("SoundManager", "Could not find sound file: $fileName in scene: $sceneName")
                onComplete?.invoke()
                return
            }

            player.setVolume(globalVolume, globalVolume)
            player.setOnCompletionListener {
                player.release()
                activePlayers.remove(player)
                onComplete?.invoke()
            }
            player.setOnErrorListener { _, what, extra ->
                Log.e("SoundManager", "MediaPlayer error: $what, $extra")
                player.release()
                activePlayers.remove(player)
                onComplete?.invoke()
                true
            }

            player.prepare()
            player.start()
            activePlayers.add(player)
        } catch (e: Exception) {
            Log.e("SoundManager", "Error playing sound: $fileName", e)
            onComplete?.invoke()
        }
    }

    private fun openAssetOrFile(
        fileName: String,
        sceneName: String,
        projectDir: String,
        player: MediaPlayer
    ): Boolean {
        // Search candidates in assets
        val cleanName = File(fileName).name
        val candidates = listOf(
            "$projectDir/$sceneName/sounds/$cleanName",
            "$projectDir/Scene/sounds/$cleanName",
            "$projectDir/sounds/$cleanName",
            "$sceneName/sounds/$cleanName",
            "sounds/$cleanName",
            cleanName
        )

        for (path in candidates) {
            try {
                val afd: AssetFileDescriptor = context.assets.openFd(path)
                player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                return true
            } catch (_: Exception) {
            }
        }

        // Search in external filesDir if user loaded from custom path
        val fileCandidates = listOf(
            File(context.filesDir, "$projectDir/$sceneName/sounds/$cleanName"),
            File(context.filesDir, "$projectDir/Scene/sounds/$cleanName"),
            File(context.filesDir, cleanName)
        )
        for (f in fileCandidates) {
            if (f.exists()) {
                player.setDataSource(f.absolutePath)
                return true
            }
        }

        return false
    }

    fun stopAll() {
        for (p in activePlayers) {
            try {
                if (p.isPlaying) p.stop()
                p.release()
            } catch (_: Exception) {}
        }
        activePlayers.clear()
    }

    fun setVolume(volume0to100: Double) {
        globalVolume = (volume0to100.toFloat() / 100f).coerceIn(0f, 1f)
        for (p in activePlayers) {
            try {
                p.setVolume(globalVolume, globalVolume)
            } catch (_: Exception) {}
        }
    }

    fun changeVolume(delta: Double) {
        val cur100 = globalVolume * 100f
        setVolume((cur100 + delta).toDouble())
    }

    fun release() {
        stopAll()
    }
}
