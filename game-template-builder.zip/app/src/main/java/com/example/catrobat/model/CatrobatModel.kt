package com.example.catrobat.model

data class ProgramHeader(
    val applicationName: String = "Pocket Code",
    val programName: String = "Pocket Code Project",
    val landscapeMode: Boolean = true,
    val screenWidth: Int = 1280,
    val screenHeight: Int = 720,
    val screenMode: String = "STRETCH",
    val description: String = "",
    val catrobatLanguageVersion: String = "1.14"
)

data class Look(
    val fileName: String,
    val name: String
)

data class Sound(
    val fileName: String,
    val name: String
)

data class FormulaNode(
    val type: String, // NUMBER, STRING, USER_VARIABLE, USER_LIST, SENSOR, OPERATOR, FUNCTION, COLLISION_FORMULA, USER_DEFINED_BRICK_INPUT
    val value: String = "",
    val leftChild: FormulaNode? = null,
    val rightChild: FormulaNode? = null,
    val additionalChildren: List<FormulaNode> = emptyList()
)

data class Brick(
    val type: String,
    val brickId: String = "",
    val commentedOut: Boolean = false,
    val formulas: Map<String, FormulaNode> = emptyMap(),
    val loopBricks: List<Brick> = emptyList(),
    val ifBranchBricks: List<Brick> = emptyList(),
    val elseBranchBricks: List<Brick> = emptyList(),
    val properties: Map<String, String> = emptyMap(),
    val userDefinedBrickID: String = "",
    val userDefinedInputs: List<String> = emptyList()
)

data class Script(
    val type: String, // StartScript, WhenScript, WhenTouchDownScript, WhenConditionScript, BroadcastScript, WhenClonedScript, UserDefinedScript, etc.
    val scriptId: String = "",
    val commentedOut: Boolean = false,
    val bricks: List<Brick> = emptyList(),
    val properties: Map<String, String> = emptyMap(),
    val conditionFormula: FormulaNode? = null,
    val userDefinedBrickID: String = "",
    val userDefinedInputs: List<String> = emptyList()
)

data class SpriteObject(
    val name: String,
    val type: String = "Sprite",
    val looks: MutableList<Look> = mutableListOf(),
    val sounds: MutableList<Sound> = mutableListOf(),
    val scripts: MutableList<Script> = mutableListOf(),
    val userVariables: MutableMap<String, Any> = mutableMapOf(),
    val userLists: MutableMap<String, MutableList<Any>> = mutableMapOf()
)

data class Scene(
    val name: String,
    val sprites: MutableList<SpriteObject> = mutableListOf()
)

data class CatrobatProgram(
    val header: ProgramHeader,
    val scenes: MutableList<Scene> = mutableListOf(),
    val globalVariables: MutableMap<String, Any> = mutableMapOf(),
    val globalLists: MutableMap<String, MutableList<Any>> = mutableMapOf()
)
