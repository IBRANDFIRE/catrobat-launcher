package com.example.catrobat.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.catrobat.engine.CatrobatEngine
import com.example.catrobat.engine.ProjectZipLoader

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameScreen(
    initialEngine: CatrobatEngine,
    onEngineReplaced: (CatrobatEngine) -> Unit
) {
    var engine by remember { mutableStateOf(initialEngine) }
    val isRunning by engine.isRunning.collectAsState()
    val currentScene by engine.currentSceneName.collectAsState()
    val logs by engine.debugLogs.collectAsState()

    var showControls by remember { mutableStateOf(true) }
    var showInspector by remember { mutableStateOf(false) }
    var showConsole by remember { mutableStateOf(false) }
    var showGuide by remember { mutableStateOf(false) }
    var showSceneMenu by remember { mutableStateOf(false) }

    val context = LocalContext.current

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val result = ProjectZipLoader.loadFromUri(context, uri)
            if (result != null) {
                engine.release()
                val newEngine = CatrobatEngine(context, result.first, result.second)
                engine = newEngine
                onEngineReplaced(newEngine)
                newEngine.start()
                Toast.makeText(context, "Loaded: ${result.first.header.programName}", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Failed to load Catrobat project zip", Toast.LENGTH_LONG).show()
            }
        }
    }

    LaunchedEffect(engine) {
        engine.start()
    }

    DisposableEffect(engine) {
        onDispose {
            engine.release()
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = Color.Black
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Canvas Game Renderer
            GameView(
                engine = engine,
                modifier = Modifier.fillMaxSize()
            )

            // Top Floating Control Pill
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .align(Alignment.TopCenter)
            ) {
                AnimatedVisibility(
                    visible = showControls,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = Color(0xDD1E1E2C),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x44FFFFFF)),
                        shadowElevation = 8.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Program Title & Scene Selector
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { showSceneMenu = true }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Column {
                                    Text(
                                        text = engine.program.header.programName,
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "Scene: $currentScene",
                                            color = Color(0xFF64B5F6),
                                            fontSize = 11.sp
                                        )
                                        Icon(
                                            imageVector = Icons.Default.ArrowDropDown,
                                            contentDescription = "Switch Scene",
                                            tint = Color(0xFF64B5F6),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }

                                DropdownMenu(
                                    expanded = showSceneMenu,
                                    onDismissRequest = { showSceneMenu = false }
                                ) {
                                    for (sc in engine.program.scenes) {
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    text = sc.name,
                                                    fontWeight = if (sc.name == currentScene) FontWeight.Bold else FontWeight.Normal
                                                )
                                            },
                                            onClick = {
                                                showSceneMenu = false
                                                engine.switchScene(sc.name)
                                            },
                                            leadingIcon = {
                                                if (sc.name == currentScene) {
                                                    Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                                }
                                            }
                                        )
                                    }
                                }
                            }

                            // Quick Action Buttons
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Play / Pause
                                IconButton(
                                    onClick = {
                                        if (isRunning) engine.pause() else engine.resume()
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = if (isRunning) "Pause" else "Play",
                                        tint = if (isRunning) Color(0xFFFFD54F) else Color(0xFF81C784),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                // Restart
                                IconButton(
                                    onClick = { engine.restart() },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "Restart",
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                // Inspector (Variables)
                                IconButton(
                                    onClick = { showInspector = true },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DataObject,
                                        contentDescription = "Variables Inspector",
                                        tint = Color(0xFF4FC3F7),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                // Console Logs
                                IconButton(
                                    onClick = { showConsole = true },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Terminal,
                                        contentDescription = "Live Console",
                                        tint = Color(0xFFAED581),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                // Template Guide
                                IconButton(
                                    onClick = { showGuide = true },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.HelpOutline,
                                        contentDescription = "Template Guide",
                                        tint = Color(0xFFFFB74D),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                // Collapse Bar
                                IconButton(
                                    onClick = { showControls = false },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.KeyboardArrowUp,
                                        contentDescription = "Hide Controls",
                                        tint = Color(0xAAFFFFFF),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Minimal Restore Chip when controls are hidden
                if (!showControls) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xCC1E1E2C),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x44FFFFFF)),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .clickable { showControls = true }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Show Controls",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Controls",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }

    // Live Variables & Lists Inspector Dialog
    if (showInspector) {
        val sprites by engine.sprites.collectAsState()
        Dialog(onDismissRequest = { showInspector = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 500.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Variables & Lists Inspector",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = { showInspector = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Text(
                                text = "Global Variables",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (engine.program.globalVariables.isEmpty()) {
                            item {
                                Text(
                                    text = "No global variables declared.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            items(engine.program.globalVariables.entries.toList()) { entry ->
                                VariableItemCard(name = entry.key, value = entry.value.toString())
                            }
                        }

                        item {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Global Lists",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (engine.program.globalLists.isEmpty()) {
                            item {
                                Text(
                                    text = "No global lists declared.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            items(engine.program.globalLists.entries.toList()) { entry ->
                                VariableItemCard(
                                    name = entry.key,
                                    value = "[${entry.value.joinToString(", ")}]"
                                )
                            }
                        }

                        item {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Sprites Status",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        items(sprites) { sr ->
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = "${sr.name} (${sr.definition.type})",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "Pos: (${sr.x.toInt()}, ${sr.y.toInt()}) | Dir: ${sr.direction.toInt()}° | Size: ${sr.size.toInt()}% | Look: ${sr.currentLookName}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Live Console Logs Dialog
    if (showConsole) {
        Dialog(onDismissRequest = { showConsole = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF1E1E2C),
                tonalElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 500.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Terminal, contentDescription = null, tint = Color(0xFFAED581))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Engine Live Console",
                                color = Color.White,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        IconButton(onClick = { showConsole = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .background(Color(0xFF12121A), RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (logs.isEmpty()) {
                            item {
                                Text(
                                    text = "Waiting for events...",
                                    color = Color(0xFF888888),
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        } else {
                            items(logs) { line ->
                                Text(
                                    text = "• $line",
                                    color = Color(0xFF81C784),
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Template & Replace Guide Dialog
    if (showGuide) {
        Dialog(onDismissRequest = { showGuide = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 600.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Pocket Engine APK Template",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = { showGuide = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Text(
                                text = "How to replace and compile for your own game:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        item {
                            GuideStepCard(
                                stepNumber = "1",
                                title = "Replace Project Files",
                                description = "Place your project's code.xml and scene folders (images & sounds) into:\napp/src/main/assets/project/"
                            )
                        }
                        item {
                            GuideStepCard(
                                stepNumber = "2",
                                title = "Configure App Title (Optional)",
                                description = "Change the app title in res/values/strings.xml (app_name) and rootProject.name in settings.gradle.kts to match your game name."
                            )
                        }
                        item {
                            GuideStepCard(
                                stepNumber = "3",
                                title = "Compile Your APK",
                                description = "Run 'gradle assembleDebug' or export the project to build a standalone APK tailored specifically for your game!"
                            )
                        }
                        item {
                            GuideStepCard(
                                stepNumber = "★",
                                title = "Live On-Device Testing",
                                description = "You can also test any Catrobat/Pocket Code project right now by picking a .catrobat or .zip file from your phone storage:"
                            )
                        }
                        item {
                            Button(
                                onClick = {
                                    showGuide = false
                                    filePickerLauncher.launch("*/*")
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.FolderOpen, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Load .catrobat / .zip Project")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VariableItemCard(name: String, value: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = name,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp
            )
            Text(
                text = value,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun GuideStepCard(stepNumber: String, title: String, description: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .background(MaterialTheme.colorScheme.primary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stepNumber,
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
