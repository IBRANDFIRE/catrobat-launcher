package com.example.catrobat.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import com.example.catrobat.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.*

data class PenStroke(
    val x1: Float,
    val y1: Float,
    val x2: Float,
    val y2: Float,
    val color: Int,
    val width: Float
)

data class PenStamp(
    val bitmap: Bitmap,
    val x: Float,
    val y: Float,
    val rotation: Float,
    val scale: Float,
    val alpha: Float
)

data class TextOverlay(
    val text: String,
    val x: Float,
    val y: Float,
    val colorHex: String = "#FF0000",
    val size: Float = 36f,
    val alignment: Int = 0 // 0: Left, 1: Center, 2: Right
)

class SpriteRuntime(
    val definition: SpriteObject,
    var name: String = definition.name,
    var isClone: Boolean = false
) {
    var x: Double = 0.0
    var y: Double = 0.0
    var direction: Double = 90.0 // Pocket Code standard: 90 is pointing right, 0 is up
    var motionDirection: Double = 90.0
    var size: Double = 100.0 // percentage
    var visible: Boolean = true
    var transparency: Double = 0.0 // 0 to 100
    var brightness: Double = 50.0 // 0 to 100
    var colorHex: String = "#C5060E"
    var layer: Int = 0
    var rotationStyle: Int = 1 // 0: LEFT_RIGHT, 1: ALL_AROUND, 2: DONT_ROTATE
    var currentLookIndex: Int = 0
    var vx: Double = 0.0
    var vy: Double = 0.0
    var angularVelocity: Double = 0.0
    var gravityX: Double = 0.0
    var gravityY: Double = -10.0
    var mass: Double = 1.0
    var bounce: Double = 80.0
    var friction: Double = 20.0
    var physicsType: String = "NONE" // NONE, FIXED, DYNAMIC

    val variables: MutableMap<String, Any> = mutableMapOf()
    val lists: MutableMap<String, MutableList<Any>> = mutableMapOf()
    val bitmaps: MutableMap<String, Bitmap> = mutableMapOf()

    // Pen state
    var penDown: Boolean = false
    var penColor: Int = android.graphics.Color.RED
    var penSize: Float = 3.15f

    // Text display
    var activeTextOverlay: TextOverlay? = null

    val currentLookName: String
        get() = if (definition.looks.isNotEmpty() && currentLookIndex in definition.looks.indices) {
            definition.looks[currentLookIndex].name
        } else ""

    fun getCurrentBitmap(): Bitmap? {
        if (definition.looks.isEmpty() || currentLookIndex !in definition.looks.indices) return null
        val look = definition.looks[currentLookIndex]
        return bitmaps[look.fileName] ?: bitmaps[look.name]
    }
}

class CatrobatEngine(
    private val context: Context,
    val program: CatrobatProgram,
    private val projectAssetDir: String = "project"
) {
    val soundManager = SoundManager(context)
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val activeScriptJobs = mutableListOf<Job>()

    private val _currentSceneName = MutableStateFlow(program.scenes.firstOrNull()?.name ?: "Scene")
    val currentSceneName: StateFlow<String> = _currentSceneName.asStateFlow()

    private val _sprites = MutableStateFlow<List<SpriteRuntime>>(emptyList())
    val sprites: StateFlow<List<SpriteRuntime>> = _sprites.asStateFlow()

    private val _penStrokes = MutableStateFlow<List<PenStroke>>(emptyList())
    val penStrokes: StateFlow<List<PenStroke>> = _penStrokes.asStateFlow()

    private val _penStamps = MutableStateFlow<List<PenStamp>>(emptyList())
    val penStamps: StateFlow<List<PenStamp>> = _penStamps.asStateFlow()

    private val _debugLogs = MutableStateFlow<List<String>>(emptyList())
    val debugLogs: StateFlow<List<String>> = _debugLogs.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    var touchX: Double = 0.0
    var touchY: Double = 0.0
    var isFingerTouching: Boolean = false

    private val sharedPreferences = context.getSharedPreferences("catrobat_prefs", Context.MODE_PRIVATE)

    fun log(msg: String) {
        Log.d("CatrobatEngine", msg)
        val list = _debugLogs.value.toMutableList()
        list.add(0, msg)
        if (list.size > 50) list.removeLast()
        _debugLogs.value = list
    }

    fun start() {
        if (_isRunning.value) return
        _isRunning.value = true
        log("Game started: ${program.header.programName}")
        loadScene(_currentSceneName.value)
        startPhysicsLoop()
    }

    fun pause() {
        _isRunning.value = false
        stopAllScripts()
        soundManager.stopAll()
        log("Game paused")
    }

    fun resume() {
        if (!_isRunning.value) {
            _isRunning.value = true
            startPhysicsLoop()
            log("Game resumed")
        }
    }

    fun restart() {
        pause()
        _penStrokes.value = emptyList()
        _penStamps.value = emptyList()
        loadScene(program.scenes.firstOrNull()?.name ?: "Scene")
        _isRunning.value = true
        startPhysicsLoop()
        log("Game restarted")
    }

    fun switchScene(sceneName: String) {
        stopAllScripts()
        loadScene(sceneName)
    }

    private fun stopAllScripts() {
        for (job in activeScriptJobs) {
            job.cancel()
        }
        activeScriptJobs.clear()
    }

    fun loadScene(sceneName: String) {
        val scene = program.scenes.firstOrNull { it.name == sceneName } ?: run {
            log("Scene not found: $sceneName")
            return
        }
        _currentSceneName.value = sceneName
        stopAllScripts()

        val runtimeSprites = mutableListOf<SpriteRuntime>()
        for ((idx, objDef) in scene.sprites.withIndex()) {
            val sr = SpriteRuntime(definition = objDef)
            sr.layer = idx
            loadBitmapsForSprite(sr, sceneName)
            runtimeSprites.add(sr)
        }
        _sprites.value = runtimeSprites

        // Launch start scripts
        for (sr in runtimeSprites) {
            for (sc in sr.definition.scripts) {
                if (sc.commentedOut) continue
                when (sc.type) {
                    "StartScript" -> launchScript(sr, sc)
                    "WhenConditionScript" -> launchConditionWatcher(sr, sc)
                }
            }
        }
    }

    private fun loadBitmapsForSprite(sr: SpriteRuntime, sceneName: String) {
        for (look in sr.definition.looks) {
            val bmp = loadBitmap(look.fileName, sceneName)
            if (bmp != null) {
                sr.bitmaps[look.fileName] = bmp
                sr.bitmaps[look.name] = bmp
            }
        }
    }

    private fun loadBitmap(fileName: String, sceneName: String): Bitmap? {
        val cleanName = File(fileName).name
        val candidates = listOf(
            "$projectAssetDir/$sceneName/images/$cleanName",
            "$projectAssetDir/Scene/images/$cleanName",
            "$projectAssetDir/images/$cleanName",
            "$sceneName/images/$cleanName",
            "images/$cleanName",
            cleanName
        )

        for (path in candidates) {
            try {
                val stream = context.assets.open(path)
                val bmp = BitmapFactory.decodeStream(stream)
                stream.close()
                if (bmp != null) return bmp
            } catch (_: Exception) {}
        }

        // Try filesDir
        val fileCandidates = listOf(
            File(context.filesDir, "$projectAssetDir/$sceneName/images/$cleanName"),
            File(context.filesDir, "$projectAssetDir/Scene/images/$cleanName"),
            File(context.filesDir, cleanName)
        )
        for (f in fileCandidates) {
            if (f.exists()) {
                val bmp = BitmapFactory.decodeFile(f.absolutePath)
                if (bmp != null) return bmp
            }
        }
        return null
    }

    private fun startPhysicsLoop() {
        scope.launch {
            while (_isRunning.value && isActive) {
                delay(16) // ~60fps
                updatePhysics(0.016)
            }
        }
    }

    private fun updatePhysics(dt: Double) {
        val list = _sprites.value
        var changed = false
        val halfW = program.header.screenWidth / 2.0
        val halfH = program.header.screenHeight / 2.0

        for (sr in list) {
            if (sr.physicsType == "DYNAMIC") {
                sr.vx += sr.gravityX * dt
                sr.vy += sr.gravityY * dt
                sr.x += sr.vx * dt
                sr.y += sr.vy * dt
                sr.direction = (sr.direction + sr.angularVelocity * dt) % 360.0

                // Edge bounce
                if (sr.x < -halfW || sr.x > halfW) {
                    sr.vx = -sr.vx * (sr.bounce / 100.0)
                    sr.x = sr.x.coerceIn(-halfW, halfW)
                }
                if (sr.y < -halfH || sr.y > halfH) {
                    sr.vy = -sr.vy * (sr.bounce / 100.0)
                    sr.y = sr.y.coerceIn(-halfH, halfH)
                }
                changed = true
            }
        }
        if (changed) {
            _sprites.value = list.toList()
        }
    }

    fun onTouchDown(screenX: Double, screenY: Double) {
        touchX = screenX
        touchY = screenY
        isFingerTouching = true

        val list = _sprites.value.sortedByDescending { it.layer }
        for (sr in list) {
            if (!sr.visible) continue
            if (isPointInsideSprite(sr, screenX, screenY)) {
                log("Touched sprite: ${sr.name}")
                // Launch WhenTouchDownScript and WhenScript
                for (sc in sr.definition.scripts) {
                    if (sc.commentedOut) continue
                    if (sc.type == "WhenTouchDownScript" || sc.type == "WhenScript") {
                        launchScript(sr, sc)
                    }
                }
                break // Only top sprite receives touch down
            }
        }
    }

    fun onTouchMove(screenX: Double, screenY: Double) {
        touchX = screenX
        touchY = screenY
    }

    fun onTouchUp() {
        isFingerTouching = false
    }

    private fun isPointInsideSprite(sr: SpriteRuntime, px: Double, py: Double): Boolean {
        val bmp = sr.getCurrentBitmap() ?: return false
        val w = bmp.width * (sr.size / 100.0)
        val h = bmp.height * (sr.size / 100.0)
        val left = sr.x - w / 2.0
        val right = sr.x + w / 2.0
        val bottom = sr.y - h / 2.0
        val top = sr.y + h / 2.0
        return px in left..right && py in bottom..top
    }

    fun broadcast(message: String): Job {
        log("Broadcast: '$message'")
        val jobs = mutableListOf<Job>()
        val list = _sprites.value
        for (sr in list) {
            for (sc in sr.definition.scripts) {
                if (sc.commentedOut) continue
                if (sc.type == "BroadcastScript" && sc.properties["receivedMessage"] == message) {
                    val j = launchScript(sr, sc)
                    jobs.add(j)
                }
            }
        }
        return scope.launch {
            jobs.joinAll()
        }
    }

    private fun launchConditionWatcher(sr: SpriteRuntime, sc: Script) {
        val job = scope.launch {
            var prevCond = false
            while (_isRunning.value && isActive) {
                val ctx = makeContext(sr)
                val condVal = sc.conditionFormula?.let { FormulaEvaluator.evaluate(it, ctx) }
                val currCond = FormulaEvaluator.toBool(condVal)
                if (currCond && !prevCond) {
                    launchScript(sr, sc)
                }
                prevCond = currCond
                delay(50)
            }
        }
        activeScriptJobs.add(job)
    }

    private fun launchScript(
        sr: SpriteRuntime,
        sc: Script,
        callArgs: Map<String, Any> = emptyMap()
    ): Job {
        val job = scope.launch {
            runBricks(sr, sc.bricks, callArgs)
        }
        activeScriptJobs.add(job)
        job.invokeOnCompletion { activeScriptJobs.remove(job) }
        return job
    }

    private suspend inline fun isCoroutineActive(): Boolean = currentCoroutineContext().isActive

    private suspend fun runBricks(
        sr: SpriteRuntime,
        bricks: List<Brick>,
        callArgs: Map<String, Any> = emptyMap()
    ) {
        for (brick in bricks) {
            if (brick.commentedOut || !isCoroutineActive() || !_isRunning.value) break
            executeBrick(sr, brick, callArgs)
        }
    }

    private suspend fun executeBrick(
        sr: SpriteRuntime,
        brick: Brick,
        callArgs: Map<String, Any>
    ) {
        val ctx = makeContext(sr, callArgs)
        when (brick.type) {
            // Control
            "WaitBrick" -> {
                val sec = FormulaEvaluator.toDouble(
                    brick.formulas["TIME_TO_WAIT_IN_SECONDS"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                delay((sec * 1000).toLong().coerceAtLeast(10))
            }
            "WaitUntilBrick" -> {
                val condNode = brick.formulas["IF_CONDITION"]
                while (isCoroutineActive() && _isRunning.value) {
                    val res = condNode?.let { FormulaEvaluator.evaluate(it, makeContext(sr, callArgs)) }
                    if (FormulaEvaluator.toBool(res)) break
                    delay(20)
                }
            }
            "ForeverBrick" -> {
                while (isCoroutineActive() && _isRunning.value) {
                    runBricks(sr, brick.loopBricks, callArgs)
                    yield()
                }
            }
            "RepeatBrick" -> {
                val count = FormulaEvaluator.toDouble(
                    brick.formulas["TIMES_TO_REPEAT"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).toInt().coerceAtLeast(0)
                for (i in 0 until count) {
                    if (!isCoroutineActive() || !_isRunning.value) break
                    runBricks(sr, brick.loopBricks, callArgs)
                    yield()
                }
            }
            "RepeatUntilBrick" -> {
                val condNode = brick.formulas["REPEAT_UNTIL_CONDITION"]
                while (isCoroutineActive() && _isRunning.value) {
                    val res = condNode?.let { FormulaEvaluator.evaluate(it, makeContext(sr, callArgs)) }
                    if (FormulaEvaluator.toBool(res)) break
                    runBricks(sr, brick.loopBricks, callArgs)
                    yield()
                }
            }
            "ForVariableFromToBrick" -> {
                val from = FormulaEvaluator.toDouble(
                    brick.formulas["FOR_LOOP_FROM"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).toInt()
                val to = FormulaEvaluator.toDouble(
                    brick.formulas["FOR_LOOP_TO"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).toInt()
                val varName = brick.properties["userVariableName"] ?: "variable"
                val step = if (from <= to) 1 else -1
                var curr = from
                while ((step > 0 && curr <= to) || (step < 0 && curr >= to)) {
                    if (!isCoroutineActive() || !_isRunning.value) break
                    setVar(sr, varName, curr.toDouble())
                    runBricks(sr, brick.loopBricks, callArgs)
                    curr += step
                    yield()
                }
            }
            "ForItemInUserListBrick" -> {
                val listName = brick.properties["FOR_ITEM_IN_USERLIST_LIST"] ?: "list"
                val varName = brick.properties["FOR_ITEM_IN_USERLIST_VARIABLE"] ?: "item"
                val list = getList(sr, listName).toList()
                for (item in list) {
                    if (!isCoroutineActive() || !_isRunning.value) break
                    setVar(sr, varName, item)
                    runBricks(sr, brick.loopBricks, callArgs)
                    yield()
                }
            }
            "IfLogicBeginBrick", "IfThenLogicBeginBrick" -> {
                val condNode = brick.formulas["IF_CONDITION"]
                val condVal = condNode?.let { FormulaEvaluator.evaluate(it, ctx) }
                if (FormulaEvaluator.toBool(condVal)) {
                    runBricks(sr, brick.ifBranchBricks, callArgs)
                } else {
                    runBricks(sr, brick.elseBranchBricks, callArgs)
                }
            }
            "BroadcastBrick" -> {
                val msg = brick.properties["broadcastMessage"] ?: ""
                broadcast(msg)
            }
            "BroadcastWaitBrick" -> {
                val msg = brick.properties["broadcastMessage"] ?: ""
                val job = broadcast(msg)
                job.join()
            }
            "SceneTransitionBrick" -> {
                val nextScene = brick.properties["sceneForTransition"] ?: ""
                if (nextScene.isNotEmpty()) {
                    withContext(Dispatchers.Main) { switchScene(nextScene) }
                }
            }
            "SceneStartBrick" -> {
                val nextScene = brick.properties["sceneToStart"] ?: ""
                if (nextScene.isNotEmpty()) {
                    withContext(Dispatchers.Main) { switchScene(nextScene) }
                }
            }
            "ExitStageBrick" -> {
                withContext(Dispatchers.Main) { restart() }
            }
            "StopScriptBrick" -> {
                currentCoroutineContext().cancel()
            }
            "WaitTillIdleBrick" -> {
                delay(100)
            }
            "CloneBrick" -> {
                val clone = SpriteRuntime(definition = sr.definition, isClone = true).apply {
                    x = sr.x
                    y = sr.y
                    direction = sr.direction
                    size = sr.size
                    visible = sr.visible
                    transparency = sr.transparency
                    layer = sr.layer + 1
                    currentLookIndex = sr.currentLookIndex
                    bitmaps.putAll(sr.bitmaps)
                    variables.putAll(sr.variables)
                }
                val curList = _sprites.value.toMutableList()
                curList.add(clone)
                _sprites.value = curList
                // Launch WhenClonedScript
                for (sc in clone.definition.scripts) {
                    if (sc.type == "WhenClonedScript" && !sc.commentedOut) {
                        launchScript(clone, sc)
                    }
                }
            }
            "DeleteThisCloneBrick" -> {
                if (sr.isClone) {
                    val curList = _sprites.value.toMutableList()
                    curList.remove(sr)
                    _sprites.value = curList
                    currentCoroutineContext().cancel()
                }
            }

            // Motion & Position
            "PlaceAtBrick" -> {
                val nx = FormulaEvaluator.toDouble(
                    brick.formulas["X_POSITION"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                val ny = FormulaEvaluator.toDouble(
                    brick.formulas["Y_POSITION"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                recordPenMovement(sr, nx, ny)
                sr.x = nx
                sr.y = ny
                triggerSpriteUpdate()
            }
            "SetXBrick" -> {
                val nx = FormulaEvaluator.toDouble(
                    brick.formulas["X_POSITION"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                recordPenMovement(sr, nx, sr.y)
                sr.x = nx
                triggerSpriteUpdate()
            }
            "SetYBrick" -> {
                val ny = FormulaEvaluator.toDouble(
                    brick.formulas["Y_POSITION"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                recordPenMovement(sr, sr.x, ny)
                sr.y = ny
                triggerSpriteUpdate()
            }
            "ChangeXByNBrick" -> {
                val dx = FormulaEvaluator.toDouble(
                    brick.formulas["X_POSITION_CHANGE"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                recordPenMovement(sr, sr.x + dx, sr.y)
                sr.x += dx
                triggerSpriteUpdate()
            }
            "ChangeYByNBrick" -> {
                val dy = FormulaEvaluator.toDouble(
                    brick.formulas["Y_POSITION_CHANGE"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                recordPenMovement(sr, sr.x, sr.y + dy)
                sr.y += dy
                triggerSpriteUpdate()
            }
            "GoToBrick" -> {
                val sel = brick.properties["spinnerSelection"] ?: ""
                val destSpriteName = brick.properties["destinationSpriteName"]
                if (sel == "80") {
                    // Random or finger
                    val hw = program.header.screenWidth / 2.0
                    val hh = program.header.screenHeight / 2.0
                    val nx = (Math.random() * hw * 2) - hw
                    val ny = (Math.random() * hh * 2) - hh
                    recordPenMovement(sr, nx, ny)
                    sr.x = nx
                    sr.y = ny
                } else if (!destSpriteName.isNullOrBlank()) {
                    val target = _sprites.value.firstOrNull { it.name == destSpriteName }
                    if (target != null) {
                        recordPenMovement(sr, target.x, target.y)
                        sr.x = target.x
                        sr.y = target.y
                    }
                }
                triggerSpriteUpdate()
            }
            "IfOnEdgeBounceBrick" -> {
                val halfW = program.header.screenWidth / 2.0
                val halfH = program.header.screenHeight / 2.0
                var bounced = false
                if (sr.x < -halfW || sr.x > halfW) {
                    sr.direction = 360.0 - sr.direction
                    bounced = true
                }
                if (sr.y < -halfH || sr.y > halfH) {
                    sr.direction = 180.0 - sr.direction
                    bounced = true
                }
                if (bounced) {
                    sr.x = sr.x.coerceIn(-halfW, halfW)
                    sr.y = sr.y.coerceIn(-halfH, halfH)
                    triggerSpriteUpdate()
                }
            }
            "MoveNStepsBrick" -> {
                val steps = FormulaEvaluator.toDouble(
                    brick.formulas["STEPS"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                val rad = Math.toRadians(sr.direction)
                val nx = sr.x + steps * sin(rad)
                val ny = sr.y + steps * cos(rad)
                recordPenMovement(sr, nx, ny)
                sr.x = nx
                sr.y = ny
                triggerSpriteUpdate()
            }
            "TurnLeftBrick" -> {
                val deg = FormulaEvaluator.toDouble(
                    brick.formulas["TURN_LEFT_DEGREES"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                sr.direction = (sr.direction - deg) % 360.0
                triggerSpriteUpdate()
            }
            "TurnRightBrick" -> {
                val deg = FormulaEvaluator.toDouble(
                    brick.formulas["TURN_RIGHT_DEGREES"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                sr.direction = (sr.direction + deg) % 360.0
                triggerSpriteUpdate()
            }
            "PointInDirectionBrick" -> {
                val deg = FormulaEvaluator.toDouble(
                    brick.formulas["DEGREES"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                sr.direction = deg % 360.0
                triggerSpriteUpdate()
            }
            "PointToBrick" -> {
                val destSpriteName = brick.properties["destinationSpriteName"]
                if (!destSpriteName.isNullOrBlank()) {
                    val target = _sprites.value.firstOrNull { it.name == destSpriteName }
                    if (target != null) {
                        val dx = target.x - sr.x
                        val dy = target.y - sr.y
                        sr.direction = Math.toDegrees(atan2(dx, dy)) % 360.0
                        triggerSpriteUpdate()
                    }
                }
            }
            "ArcBrick" -> {
                val sizeVal = FormulaEvaluator.toDouble(
                    brick.formulas["SIZE"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                val deg = FormulaEvaluator.toDouble(
                    brick.formulas["DEGREES"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                val dir = brick.properties["direction"] ?: "LEFT"
                val sign = if (dir.uppercase() == "LEFT") -1.0 else 1.0
                sr.direction = (sr.direction + sign * deg) % 360.0
                triggerSpriteUpdate()
            }
            "SetRotationStyleBrick" -> {
                val sel = brick.properties["selection"]?.toIntOrNull() ?: 1
                sr.rotationStyle = sel
                triggerSpriteUpdate()
            }
            "GlideToBrick" -> {
                val dx = FormulaEvaluator.toDouble(
                    brick.formulas["X_DESTINATION"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                val dy = FormulaEvaluator.toDouble(
                    brick.formulas["Y_DESTINATION"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                val duration = FormulaEvaluator.toDouble(
                    brick.formulas["DURATION_IN_SECONDS"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).coerceAtLeast(0.01)

                val startX = sr.x
                val startY = sr.y
                val startTime = System.currentTimeMillis()
                val totalMs = (duration * 1000).toLong()

                while (isCoroutineActive() && _isRunning.value) {
                    val elapsed = System.currentTimeMillis() - startTime
                    val progress = (elapsed.toDouble() / totalMs).coerceIn(0.0, 1.0)
                    val nx = startX + (dx - startX) * progress
                    val ny = startY + (dy - startY) * progress
                    recordPenMovement(sr, nx, ny)
                    sr.x = nx
                    sr.y = ny
                    triggerSpriteUpdate()
                    if (progress >= 1.0) break
                    delay(16)
                }
            }
            "GoNStepsBackBrick" -> {
                val steps = FormulaEvaluator.toDouble(
                    brick.formulas["STEPS"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).toInt()
                sr.layer = (sr.layer - steps).coerceAtLeast(0)
                sortSpriteLayers()
            }
            "ComeToFrontBrick" -> {
                val maxLayer = _sprites.value.maxOfOrNull { it.layer } ?: 0
                sr.layer = maxLayer + 1
                sortSpriteLayers()
            }
            "VibrationBrick" -> {
                val durationSec = FormulaEvaluator.toDouble(
                    brick.formulas["VIBRATE_DURATION_IN_SECONDS"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).coerceAtLeast(0.05)
                vibrate((durationSec * 1000).toLong())
            }

            // Physics
            "SetPhysicsObjectTypeBrick" -> {
                val pType = brick.properties["type"] ?: "NONE"
                sr.physicsType = pType.uppercase()
            }
            "SetVelocityBrick" -> {
                sr.vx = FormulaEvaluator.toDouble(
                    brick.formulas["PHYSICS_VELOCITY_X"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                sr.vy = FormulaEvaluator.toDouble(
                    brick.formulas["PHYSICS_VELOCITY_Y"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
            }
            "TurnLeftSpeedBrick" -> {
                val spd = FormulaEvaluator.toDouble(
                    brick.formulas["PHYSICS_TURN_LEFT_SPEED"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                sr.angularVelocity = -spd
            }
            "TurnRightSpeedBrick" -> {
                val spd = FormulaEvaluator.toDouble(
                    brick.formulas["PHYSICS_TURN_RIGHT_SPEED"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                sr.angularVelocity = spd
            }
            "SetGravityBrick" -> {
                sr.gravityX = FormulaEvaluator.toDouble(
                    brick.formulas["PHYSICS_GRAVITY_X"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                sr.gravityY = FormulaEvaluator.toDouble(
                    brick.formulas["PHYSICS_GRAVITY_Y"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
            }
            "SetMassBrick" -> {
                sr.mass = FormulaEvaluator.toDouble(
                    brick.formulas["PHYSICS_MASS"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
            }
            "SetBounceBrick" -> {
                sr.bounce = FormulaEvaluator.toDouble(
                    brick.formulas["PHYSICS_BOUNCE_FACTOR"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
            }
            "SetFrictionBrick" -> {
                sr.friction = FormulaEvaluator.toDouble(
                    brick.formulas["PHYSICS_FRICTION"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
            }

            // Looks
            "SetLookBrick" -> {
                val lookName = brick.properties["lookName"] ?: ""
                val idx = sr.definition.looks.indexOfFirst { it.name == lookName || it.fileName == lookName }
                if (idx != -1) {
                    sr.currentLookIndex = idx
                    triggerSpriteUpdate()
                }
            }
            "SetLookByIndexBrick" -> {
                val lookIdx = FormulaEvaluator.toDouble(
                    brick.formulas["LOOK_INDEX"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).toInt() - 1 // 1-indexed
                if (sr.definition.looks.isNotEmpty()) {
                    sr.currentLookIndex = (lookIdx % sr.definition.looks.size + sr.definition.looks.size) % sr.definition.looks.size
                    triggerSpriteUpdate()
                }
            }
            "NextLookBrick" -> {
                if (sr.definition.looks.isNotEmpty()) {
                    sr.currentLookIndex = (sr.currentLookIndex + 1) % sr.definition.looks.size
                    triggerSpriteUpdate()
                }
            }
            "PreviousLookBrick" -> {
                if (sr.definition.looks.isNotEmpty()) {
                    sr.currentLookIndex = (sr.currentLookIndex - 1 + sr.definition.looks.size) % sr.definition.looks.size
                    triggerSpriteUpdate()
                }
            }
            "SetSizeToBrick" -> {
                val sz = FormulaEvaluator.toDouble(
                    brick.formulas["SIZE"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                sr.size = sz.coerceAtLeast(1.0)
                triggerSpriteUpdate()
            }
            "ChangeSizeByNBrick" -> {
                val dsz = FormulaEvaluator.toDouble(
                    brick.formulas["SIZE_CHANGE"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                sr.size = (sr.size + dsz).coerceAtLeast(1.0)
                triggerSpriteUpdate()
            }
            "HideBrick" -> {
                sr.visible = false
                triggerSpriteUpdate()
            }
            "ShowBrick" -> {
                sr.visible = true
                triggerSpriteUpdate()
            }
            "SetTransparencyBrick" -> {
                val tr = FormulaEvaluator.toDouble(
                    brick.formulas["TRANSPARENCY"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                sr.transparency = tr.coerceIn(0.0, 100.0)
                triggerSpriteUpdate()
            }
            "ChangeTransparencyByNBrick" -> {
                val dtr = FormulaEvaluator.toDouble(
                    brick.formulas["TRANSPARENCY_CHANGE"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                sr.transparency = (sr.transparency + dtr).coerceIn(0.0, 100.0)
                triggerSpriteUpdate()
            }
            "SetBrightnessBrick" -> {
                val br = FormulaEvaluator.toDouble(
                    brick.formulas["BRIGHTNESS"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                sr.brightness = br.coerceIn(0.0, 100.0)
                triggerSpriteUpdate()
            }
            "ChangeBrightnessByNBrick" -> {
                val dbr = FormulaEvaluator.toDouble(
                    brick.formulas["BRIGHTNESS_CHANGE"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                sr.brightness = (sr.brightness + dbr).coerceIn(0.0, 100.0)
                triggerSpriteUpdate()
            }
            "ShowTextBrick" -> {
                val varName = brick.properties["userVariableName"] ?: "variable"
                val tx = FormulaEvaluator.toDouble(
                    brick.formulas["X_POSITION"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).toFloat()
                val ty = FormulaEvaluator.toDouble(
                    brick.formulas["Y_POSITION"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).toFloat()
                val displayStr = FormulaEvaluator.toDisplayString(getVar(sr, varName))
                sr.activeTextOverlay = TextOverlay(text = displayStr, x = tx, y = ty)
                triggerSpriteUpdate()
            }
            "ShowTextColorSizeAlignmentBrick" -> {
                val varName = brick.properties["userVariableName"] ?: "variable"
                val tx = FormulaEvaluator.toDouble(
                    brick.formulas["X_POSITION"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).toFloat()
                val ty = FormulaEvaluator.toDouble(
                    brick.formulas["Y_POSITION"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).toFloat()
                val sz = FormulaEvaluator.toDouble(
                    brick.formulas["SIZE"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).toFloat().coerceAtLeast(10f)
                val col = FormulaEvaluator.toDisplayString(
                    brick.formulas["COLOR"]?.let { FormulaEvaluator.evaluate(it, ctx) } ?: "#FF0000"
                )
                val align = brick.properties["alignmentSelection"]?.toIntOrNull() ?: 1
                val displayStr = FormulaEvaluator.toDisplayString(getVar(sr, varName))
                sr.activeTextOverlay = TextOverlay(
                    text = displayStr,
                    x = tx,
                    y = ty,
                    colorHex = col,
                    size = sz,
                    alignment = align
                )
                triggerSpriteUpdate()
            }
            "HideTextBrick" -> {
                sr.activeTextOverlay = null
                triggerSpriteUpdate()
            }
            "SetColorBrick" -> {
                val colVal = brick.formulas["COLOR"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                sr.colorHex = FormulaEvaluator.toDisplayString(colVal ?: "#FFFFFF")
                triggerSpriteUpdate()
            }
            "ChangeColorByNBrick" -> {
                // cycle hue
                triggerSpriteUpdate()
            }
            "SetBackgroundByIndexBrick" -> {
                val bgSprite = _sprites.value.firstOrNull { it.name.equals("Background", ignoreCase = true) }
                val idx = FormulaEvaluator.toDouble(
                    brick.formulas["BACKGROUND_INDEX"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).toInt() - 1
                if (bgSprite != null && bgSprite.definition.looks.isNotEmpty()) {
                    bgSprite.currentLookIndex = (idx % bgSprite.definition.looks.size + bgSprite.definition.looks.size) % bgSprite.definition.looks.size
                    triggerSpriteUpdate()
                }
            }
            "SetBackgroundAndWaitBrick" -> {
                val bgSprite = _sprites.value.firstOrNull { it.name.equals("Background", ignoreCase = true) }
                val lookName = brick.properties["lookName"] ?: ""
                if (bgSprite != null) {
                    val idx = bgSprite.definition.looks.indexOfFirst { it.name == lookName || it.fileName == lookName }
                    if (idx != -1) {
                        bgSprite.currentLookIndex = idx
                        triggerSpriteUpdate()
                        delay(50)
                    }
                }
            }
            "LookRequestBrick" -> {
                val url = FormulaEvaluator.toDisplayString(
                    brick.formulas["LOOK_REQUEST"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                loadLookFromUrl(sr, url)
            }

            // Sounds
            "PlaySoundBrick" -> {
                val soundFile = brick.properties["soundFileName"] ?: brick.properties["soundName"] ?: ""
                if (soundFile.isNotEmpty()) {
                    soundManager.playSound(soundFile, _currentSceneName.value, projectAssetDir)
                }
            }
            "PlaySoundAndWaitBrick" -> {
                val soundFile = brick.properties["soundFileName"] ?: brick.properties["soundName"] ?: ""
                if (soundFile.isNotEmpty()) {
                    val waitJob = CompletableDeferred<Unit>()
                    soundManager.playSound(soundFile, _currentSceneName.value, projectAssetDir, wait = true) {
                        waitJob.complete(Unit)
                    }
                    waitJob.await()
                }
            }
            "PlaySoundAtBrick" -> {
                val soundFile = brick.properties["soundFileName"] ?: brick.properties["soundName"] ?: ""
                if (soundFile.isNotEmpty()) {
                    soundManager.playSound(soundFile, _currentSceneName.value, projectAssetDir)
                }
            }
            "StopSoundBrick" -> {
                // Stop sound
            }
            "StopAllSoundsBrick" -> {
                soundManager.stopAll()
            }
            "SetVolumeToBrick" -> {
                val vol = FormulaEvaluator.toDouble(
                    brick.formulas["VOLUME"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                soundManager.setVolume(vol)
            }
            "ChangeVolumeByNBrick" -> {
                val dvol = FormulaEvaluator.toDouble(
                    brick.formulas["VOLUME_CHANGE"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                soundManager.changeVolume(dvol)
            }

            // Pen
            "PenDownBrick" -> sr.penDown = true
            "PenUpBrick" -> sr.penDown = false
            "SetPenSizeBrick" -> {
                val sz = FormulaEvaluator.toDouble(
                    brick.formulas["PEN_SIZE"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).toFloat().coerceAtLeast(1f)
                sr.penSize = sz
            }
            "SetPenColorBrick" -> {
                val r = FormulaEvaluator.toDouble(
                    brick.formulas["PEN_COLOR_RED"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).toInt().coerceIn(0, 255)
                val g = FormulaEvaluator.toDouble(
                    brick.formulas["PEN_COLOR_GREEN"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).toInt().coerceIn(0, 255)
                val b = FormulaEvaluator.toDouble(
                    brick.formulas["PEN_COLOR_BLUE"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).toInt().coerceIn(0, 255)
                sr.penColor = android.graphics.Color.rgb(r, g, b)
            }
            "StampBrick" -> {
                val bmp = sr.getCurrentBitmap()
                if (bmp != null) {
                    val stamp = PenStamp(
                        bitmap = bmp,
                        x = sr.x.toFloat(),
                        y = sr.y.toFloat(),
                        rotation = sr.direction.toFloat(),
                        scale = (sr.size / 100.0).toFloat(),
                        alpha = (1.0 - sr.transparency / 100.0).toFloat()
                    )
                    _penStamps.value = _penStamps.value + stamp
                }
            }
            "ClearBackgroundBrick" -> {
                _penStrokes.value = emptyList()
                _penStamps.value = emptyList()
            }

            // Data / Variables / Lists
            "SetVariableBrick" -> {
                val varName = brick.properties["userVariableName"] ?: "variable"
                val value = brick.formulas["VARIABLE"]?.let { FormulaEvaluator.evaluate(it, ctx) } ?: 0.0
                setVar(sr, varName, value)
                log("Set variable '$varName' = $value")
            }
            "ChangeVariableBrick" -> {
                val varName = brick.properties["userVariableName"] ?: "variable"
                val delta = FormulaEvaluator.toDouble(
                    brick.formulas["VARIABLE_CHANGE"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                )
                val curVal = FormulaEvaluator.toDouble(getVar(sr, varName))
                val newVal = curVal + delta
                setVar(sr, varName, newVal)
                log("Change variable '$varName' += $delta (now $newVal)")
            }
            "WriteVariableOnDeviceBrick" -> {
                val varName = brick.properties["userVariableName"] ?: "variable"
                val curVal = getVar(sr, varName)
                sharedPreferences.edit().putString("cat_var_$varName", curVal.toString()).apply()
            }
            "ReadVariableFromDeviceBrick" -> {
                val varName = brick.properties["userVariableName"] ?: "variable"
                val stored = sharedPreferences.getString("cat_var_$varName", null)
                if (stored != null) {
                    val num = stored.toDoubleOrNull()
                    setVar(sr, varName, num ?: stored)
                }
            }
            "WriteVariableToFileBrick" -> {
                val varName = brick.properties["userVariableName"] ?: "variable"
                val fileName = FormulaEvaluator.toDisplayString(
                    brick.formulas["WRITE_FILENAME"]?.let { FormulaEvaluator.evaluate(it, ctx) } ?: "variable.txt"
                )
                val curVal = getVar(sr, varName)
                try {
                    File(context.filesDir, fileName).writeText(curVal.toString())
                } catch (e: Exception) {
                    Log.e("CatrobatEngine", "Error writing file $fileName", e)
                }
            }
            "ReadVariableFromFileBrick" -> {
                val varName = brick.properties["userVariableName"] ?: "variable"
                val fileName = FormulaEvaluator.toDisplayString(
                    brick.formulas["READ_FILENAME"]?.let { FormulaEvaluator.evaluate(it, ctx) } ?: "variable.txt"
                )
                try {
                    val f = File(context.filesDir, fileName)
                    if (f.exists()) {
                        val text = f.readText().trim()
                        val num = text.toDoubleOrNull()
                        setVar(sr, varName, num ?: text)
                    }
                } catch (e: Exception) {
                    Log.e("CatrobatEngine", "Error reading file $fileName", e)
                }
            }
            "AddItemToUserListBrick" -> {
                val listName = brick.properties["userListName"] ?: "list"
                val item = brick.formulas["LIST_ADD_ITEM"]?.let { FormulaEvaluator.evaluate(it, ctx) } ?: 0.0
                getList(sr, listName).add(item)
            }
            "DeleteItemOfUserListBrick" -> {
                val listName = brick.properties["userListName"] ?: "list"
                val idx = FormulaEvaluator.toDouble(
                    brick.formulas["LIST_DELETE_ITEM"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).toInt() - 1
                val list = getList(sr, listName)
                if (idx in list.indices) list.removeAt(idx)
            }
            "ClearUserListBrick" -> {
                val listName = brick.properties["userListName"] ?: "list"
                getList(sr, listName).clear()
            }
            "InsertItemIntoUserListBrick" -> {
                val listName = brick.properties["userListName"] ?: "list"
                val idx = FormulaEvaluator.toDouble(
                    brick.formulas["INSERT_ITEM_INTO_USERLIST_INDEX"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).toInt() - 1
                val item = brick.formulas["INSERT_ITEM_INTO_USERLIST_VALUE"]?.let { FormulaEvaluator.evaluate(it, ctx) } ?: 0.0
                val list = getList(sr, listName)
                if (idx in 0..list.size) list.add(idx, item) else list.add(item)
            }
            "ReplaceItemInUserListBrick" -> {
                val listName = brick.properties["userListName"] ?: "list"
                val idx = FormulaEvaluator.toDouble(
                    brick.formulas["REPLACE_ITEM_IN_USERLIST_INDEX"]?.let { FormulaEvaluator.evaluate(it, ctx) }
                ).toInt() - 1
                val item = brick.formulas["REPLACE_ITEM_IN_USERLIST_VALUE"]?.let { FormulaEvaluator.evaluate(it, ctx) } ?: 0.0
                val list = getList(sr, listName)
                if (idx in list.indices) list[idx] = item
            }
            "WriteListOnDeviceBrick" -> {
                val listName = brick.properties["userListName"] ?: "list"
                val list = getList(sr, listName)
                sharedPreferences.edit().putString("cat_list_$listName", list.joinToString("\n")).apply()
            }
            "ReadListFromDeviceBrick" -> {
                val listName = brick.properties["userListName"] ?: "list"
                val str = sharedPreferences.getString("cat_list_$listName", null)
                if (str != null) {
                    val list = getList(sr, listName)
                    list.clear()
                    for (line in str.lines()) {
                        if (line.isNotEmpty()) {
                            list.add(line.toDoubleOrNull() ?: line)
                        }
                    }
                }
            }
            "StoreCSVIntoUserListBrick" -> {
                val listName = brick.properties["userListName"] ?: "list"
                val csv = FormulaEvaluator.toDisplayString(
                    brick.formulas["STORE_CSV_INTO_USERLIST_CSV"]?.let { FormulaEvaluator.evaluate(it, ctx) } ?: ""
                )
                val items = csv.split(",").map { it.trim() }
                val list = getList(sr, listName)
                list.clear()
                for (it in items) {
                    list.add(it.toDoubleOrNull() ?: it)
                }
            }
            "WebRequestBrick" -> {
                val urlStr = FormulaEvaluator.toDisplayString(
                    brick.formulas["WEB_REQUEST"]?.let { FormulaEvaluator.evaluate(it, ctx) } ?: ""
                )
                val varName = brick.properties["userVariableName"] ?: "variable"
                scope.launch(Dispatchers.IO) {
                    try {
                        val conn = URL(urlStr).openConnection() as HttpURLConnection
                        conn.connectTimeout = 3000
                        conn.readTimeout = 3000
                        val text = conn.inputStream.bufferedReader().readText()
                        conn.disconnect()
                        setVar(sr, varName, text)
                    } catch (e: Exception) {
                        Log.e("CatrobatEngine", "WebRequest error: $urlStr", e)
                    }
                }
            }

            // Custom UserDefinedBrick
            "UserDefinedBrick" -> {
                val brickId = brick.userDefinedBrickID
                // Find matching UserDefinedScript
                val targetScript = sr.definition.scripts.firstOrNull {
                    it.type == "UserDefinedScript" && it.userDefinedBrickID == brickId
                }
                if (targetScript != null) {
                    val passedArgs = mutableMapOf<String, Any>()
                    for ((argIdx, inputName) in targetScript.userDefinedInputs.withIndex()) {
                        val inputValNode = brick.formulas[inputName] ?: brick.formulas.values.elementAtOrNull(argIdx)
                        val evaluatedArg = inputValNode?.let { FormulaEvaluator.evaluate(it, ctx) } ?: 0.0
                        passedArgs[inputName] = evaluatedArg
                    }
                    runBricks(sr, targetScript.bricks, passedArgs)
                }
            }
        }
    }

    private fun recordPenMovement(sr: SpriteRuntime, newX: Double, newY: Double) {
        if (sr.penDown) {
            val stroke = PenStroke(
                x1 = sr.x.toFloat(),
                y1 = sr.y.toFloat(),
                x2 = newX.toFloat(),
                y2 = newY.toFloat(),
                color = sr.penColor,
                width = sr.penSize
            )
            _penStrokes.value = _penStrokes.value + stroke
        }
    }

    private fun triggerSpriteUpdate() {
        _sprites.value = _sprites.value.toList()
    }

    private fun sortSpriteLayers() {
        _sprites.value = _sprites.value.sortedBy { it.layer }
    }

    private fun loadLookFromUrl(sr: SpriteRuntime, urlStr: String) {
        scope.launch(Dispatchers.IO) {
            try {
                val stream: InputStream = URL(urlStr).openStream()
                val bmp = BitmapFactory.decodeStream(stream)
                stream.close()
                if (bmp != null) {
                    val key = "url_${System.currentTimeMillis()}"
                    sr.bitmaps[key] = bmp
                    sr.definition.looks.add(Look(fileName = key, name = key))
                    sr.currentLookIndex = sr.definition.looks.size - 1
                    triggerSpriteUpdate()
                }
            } catch (e: Exception) {
                Log.e("CatrobatEngine", "Failed to load look from $urlStr", e)
            }
        }
    }

    private fun vibrate(durationMs: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                v?.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }

    fun getVar(sr: SpriteRuntime, name: String): Any {
        return sr.variables[name] ?: program.globalVariables[name] ?: 0.0
    }

    fun setVar(sr: SpriteRuntime, name: String, value: Any) {
        if (program.globalVariables.containsKey(name) || !sr.variables.containsKey(name)) {
            program.globalVariables[name] = value
        } else {
            sr.variables[name] = value
        }
    }

    fun getList(sr: SpriteRuntime, name: String): MutableList<Any> {
        return sr.lists[name] ?: program.globalLists.getOrPut(name) { mutableListOf() }
    }

    private fun makeContext(sr: SpriteRuntime, callArgs: Map<String, Any> = emptyMap()): EngineContext {
        return object : EngineContext {
            override fun getVariable(name: String): Any = getVar(sr, name)

            override fun getList(name: String): List<Any> = getList(sr, name)

            override fun getCustomInput(name: String): Any? = callArgs[name]

            override fun getSpriteSensor(sensorName: String): Any {
                val halfW = program.header.screenWidth / 2.0
                val halfH = program.header.screenHeight / 2.0
                return when (sensorName.uppercase()) {
                    "OBJECT_X" -> sr.x
                    "OBJECT_Y" -> sr.y
                    "OBJECT_SIZE" -> sr.size
                    "LOOK_DIRECTION" -> sr.direction
                    "MOTION_DIRECTION" -> sr.motionDirection
                    "OBJECT_TRANSPARENCY" -> sr.transparency
                    "OBJECT_BRIGHTNESS" -> sr.brightness
                    "OBJECT_COLOR" -> sr.colorHex
                    "OBJECT_LOOK_NUMBER" -> (sr.currentLookIndex + 1).toDouble()
                    "OBJECT_LOOK_NAME" -> sr.currentLookName
                    "OBJECT_LAYER" -> sr.layer.toDouble()
                    "COLLIDES_WITH_EDGE" -> {
                        if (sr.x <= -halfW || sr.x >= halfW || sr.y <= -halfH || sr.y >= halfH) 1.0 else 0.0
                    }
                    "COLLIDES_WITH_FINGER" -> {
                        if (isFingerTouching && isPointInsideSprite(sr, touchX, touchY)) 1.0 else 0.0
                    }
                    "OBJECT_X_VELOCITY" -> sr.vx
                    "OBJECT_Y_VELOCITY" -> sr.vy
                    "OBJECT_ANGULAR_VELOCITY" -> sr.angularVelocity
                    else -> 0.0
                }
            }

            override fun checkCollision(spriteName: String): Boolean {
                val other = _sprites.value.firstOrNull { it.name == spriteName && it != sr && it.visible }
                    ?: return false
                val bmp1 = sr.getCurrentBitmap() ?: return false
                val bmp2 = other.getCurrentBitmap() ?: return false
                val w1 = bmp1.width * (sr.size / 100.0)
                val h1 = bmp1.height * (sr.size / 100.0)
                val w2 = bmp2.width * (other.size / 100.0)
                val h2 = bmp2.height * (other.size / 100.0)

                return (abs(sr.x - other.x) * 2 < (w1 + w2)) &&
                        (abs(sr.y - other.y) * 2 < (h1 + h2))
            }

            override fun checkColorTouchesColor(color1: String, color2: String): Boolean = false

            override fun checkCollidesWithColor(color: String): Boolean = false
        }
    }

    fun release() {
        pause()
        soundManager.release()
        scope.cancel()
    }
}
