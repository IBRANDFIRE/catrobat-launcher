package com.example

import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.catrobat.engine.CatrobatEngine
import com.example.catrobat.engine.ProjectZipLoader
import com.example.catrobat.model.CatrobatProgram
import com.example.catrobat.parser.CatrobatParser
import com.example.catrobat.ui.GameScreen
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private var engine: CatrobatEngine? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                var currentEngine by remember { mutableStateOf<CatrobatEngine?>(null) }
                var loadError by remember { mutableStateOf<String?>(null) }
                var retryTrigger by remember { mutableIntStateOf(0) }

                val filePickerLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.GetContent()
                ) { uri: Uri? ->
                    if (uri != null) {
                        val result = ProjectZipLoader.loadFromUri(this@MainActivity, uri)
                        if (result != null) {
                            engine?.release()
                            val newEngine = CatrobatEngine(this@MainActivity, result.first, result.second)
                            engine = newEngine
                            currentEngine = newEngine
                            loadError = null
                            newEngine.start()
                            Toast.makeText(this@MainActivity, "Loaded: ${result.first.header.programName}", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this@MainActivity, "Failed to load project zip", Toast.LENGTH_LONG).show()
                        }
                    }
                }

                LaunchedEffect(retryTrigger) {
                    try {
                        loadError = null
                        val (program, assetDir) = withContext(Dispatchers.IO) {
                            loadDefaultProgram()
                        }
                        if (program.header.landscapeMode) {
                            try {
                                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                            } catch (_: Exception) {}
                        }
                        val eng = CatrobatEngine(this@MainActivity, program, assetDir)
                        engine = eng
                        currentEngine = eng
                    } catch (e: Exception) {
                        Log.e("MainActivity", "Error loading project", e)
                        loadError = e.message ?: "Failed to parse code.xml"
                    }
                }

                when {
                    currentEngine != null -> {
                        GameScreen(
                            initialEngine = currentEngine!!,
                            onEngineReplaced = { newEng ->
                                engine = newEng
                                currentEngine = newEng
                            }
                        )
                    }
                    loadError != null -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color(0xFF13131A))
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("error_card"),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E2E))
                            ) {
                                Column(
                                    modifier = Modifier.padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = "Project Loading Error",
                                        color = Color(0xFFFF6E6E),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = loadError ?: "Unknown error",
                                        color = Color(0xFFE2E2F0),
                                        fontSize = 13.sp,
                                        fontFamily = FontFamily.Monospace,
                                        lineHeight = 18.sp
                                    )
                                    Spacer(modifier = Modifier.height(20.dp))
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = { retryTrigger++ },
                                            modifier = Modifier.testTag("retry_button")
                                        ) {
                                            Text("Retry")
                                        }
                                        Button(
                                            onClick = { filePickerLauncher.launch("*/*") },
                                            modifier = Modifier.testTag("load_file_button")
                                        ) {
                                            Text("Open .catrobat / .zip")
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color(0xFF12121A)),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = Color(0xFF64B5F6))
                        }
                    }
                }
            }
        }
    }

    private fun loadDefaultProgram(): Pair<CatrobatProgram, String> {
        val candidatePairs = mutableListOf(
            "project/code.xml" to "project",
            "code.xml" to ""
        )

        try {
            assets.list("")?.forEach { name ->
                if (name != "project" && name != "images" && name != "sounds" && !name.contains(".")) {
                    candidatePairs.add("$name/code.xml" to name)
                }
            }
        } catch (_: Exception) {}

        var lastParseError: Throwable? = null
        var foundFile = false

        for ((path, dir) in candidatePairs) {
            val exists = try {
                assets.open(path).use { true }
            } catch (_: Exception) {
                false
            }

            if (exists) {
                foundFile = true
                try {
                    assets.open(path).use { stream ->
                        val prog = CatrobatParser.parse(stream)
                        return Pair(prog, dir)
                    }
                } catch (e: Throwable) {
                    Log.e("MainActivity", "Found $path but failed to parse it", e)
                    lastParseError = e
                    break
                }
            }
        }

        if (lastParseError != null) {
            throw IllegalStateException("Failed to parse code.xml: ${lastParseError.message}", lastParseError)
        }
        if (!foundFile) {
            val checked = candidatePairs.joinToString { it.first }
            throw IllegalStateException("code.xml not found in assets. Checked paths: $checked")
        }
        throw IllegalStateException("Failed to load Catrobat project")
    }

    override fun onDestroy() {
        super.onDestroy()
        engine?.release()
    }
}

